#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void leggi_int_valido(int *num, int indice) {
    char buffer[100];
    char *endptr;
    long val;
    while (1) {
        printf("[%d]: ", indice + 1);
        if (!fgets(buffer, sizeof(buffer), stdin)) {
            printf("Errore di input. Riprova.\n");
            continue;
        }
        val = strtol(buffer, &endptr, 10);
        if (endptr == buffer || (*endptr != '\n' && *endptr != '\0')) {
            printf("Input non valido, inserire un numero intero.\n");
            continue;
        }
        if (val < INT_MIN || val > INT_MAX) {
            printf("Numero fuori dai limiti consentiti (%d a %d).\n", INT_MIN, INT_MAX);
            continue;
        }
        *num = (int)val;
        break;
    }
}

int main() {
    int scelta;
    int vector[10], i, j, k;
    int swap_var;
    int result;

    do {
        printf("Scegli modalità:\n");
        printf("1 - Esegui normalmente\n");
        printf("2 - Esegui con segmentation fault\n");
        printf("Scelta: ");

        result = scanf("%d", &scelta);

        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF);

        if (result != 1 || (scelta != 1 && scelta != 2)) {
            printf("Scelta non valida. Inserire solo 1 o 2.\n");
        }
    } while (result != 1 || (scelta != 1 && scelta != 2));

    printf("\nInserire 10 interi:\n");
    for (i = 0; i < 10; i++) {
        leggi_int_valido(&vector[i], i);
    }

    printf("Il vettore inserito e':\n");
    for (i = 0; i < 10; i++) {
        printf("[%d]: %d\n", i + 1, vector[i]);
    }

    for (j = 0; j < 9; j++) {
        for (k = 0; k < 9 - j; k++) {
            if (vector[k] > vector[k + 1]) {
                swap_var = vector[k];
                vector[k] = vector[k + 1];
                vector[k + 1] = swap_var;
            }
        }
    }

    printf("Il vettore ordinato e':\n");
    for (j = 0; j < 10; j++) {
        printf("[%d]: %d\n", j + 1, vector[j]);
    }

    if (scelta == 2) {
        int *ptr = NULL;
        printf("\nModalità con errore attivata. Provocando segmentation fault...\n");
        *ptr = 123;  // crash volontario
        return 1;
    }

    return 0;
}